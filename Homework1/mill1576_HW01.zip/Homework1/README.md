The zip file for homework 1 should include output images for each task 1-7 for both
the checkerboard image given to us denoted checkerboard_task<N>.png where N is the task.
Similarly, the image I used was flower.png and the output for each task is
flower_task<N>.png

There are two charts, taskB_chart.png and taskC_chart.png showing the output for each chart.
There are also two corresponding files containing their data marked as TaskB_data.txt and TaskC_data.txt
I did not include any output images for these tasks as they are primarily focused on time and
the number of operations performed.


